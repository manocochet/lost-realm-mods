Aether Excalibur Support License:
══════════════════════════════════════════════════════════════════════════

All Rights Reserved

Noncommercial Waiver
- You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
are monetized by advertising, as long as there's a direct link to an official Excalibur and the Aether Excalibur Support download page.

If you have any inquires, contact me through Discord.
Discord: @tc._

Excalibur License:
══════════════════════════════════════════════════════════════════════════

Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
http://creativecommons.org/licenses/by-nc-nd/3.0/us/

In other words:
- You may not redistribute this pack and claim it as your own.
- You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
- You may not put money-making links such as adf.ly with this work under any circumstances.
- You may not use this work for commercial purposes.
- You may not alter, transform, or build upon this work.

Noncommercial Waiver
- You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
are monetized by advertising, as long as there's a direct link to an official Excalibur download page.

Any of the above conditions can be waived if you get permission from Maffhew.
Discord: @maffhew

Installation: 
══════════════════════════════════════════════════════════════════════════
> Launch Minecraft and click on "Options"

> Click on "Resource Packs"

> Click on "Open Resource Pack Folder"

> Drag the AetherExcaliburSupport.zip file into the resource pack folder
  
> Move the Aether Excalibur Support resource pack from the left column to the right

> Make sure that the support pack is moved above the original Excalibur resourcepack

> Select "Done" 

> The skies await