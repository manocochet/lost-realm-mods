#version 120

#define OVERWORLD_SHADER
#define TWILIGHT_FOREST_FLAG

#include "/dimensions/deferred2.vsh"